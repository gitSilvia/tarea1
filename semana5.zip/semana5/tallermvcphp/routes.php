<?php     
    define('PROJECT_PATH', '/'.'semana5/tallermvcphp/');
    define('ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].PROJECT_PATH);
    define('CONTROLLER_PATH', ROOT_PATH.'controller/');
    define('MODEL_PATH', ROOT_PATH.'model/');
    define('DAO_PATH', ROOT_PATH.'dao/');
    define('VIEW_PATH', ROOT_PATH.'view/');
    define('ASSETS_PATH', ROOT_PATH.'assets/');

    define('ROOT_SERVER', $_SERVER['SERVER_NAME'].'/'.'semana5/tallermvcphp/');   
 ?>
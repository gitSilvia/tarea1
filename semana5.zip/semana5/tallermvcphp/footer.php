<script src="/semana5/tallermvcphp/assets/js/bootstrap.bundle.min.js"></script>
<script src="/semana5/tallermvcphp/assets/js/jquery.min.js"></script>
<script src="/semana5/tallermvcphp/assets/js/sweetalert2.all.min.js"></script>
<script src="/semana5/tallermvcphp/assets/js/select2.full.min.js"></script>
<script src="/semana5/tallermvcphp/assets/js/datatables.min.js"></script>
<script src="/semana5/tallermvcphp/assets/js/all.min.js"></script>
<script src="/semana5/tallermvcphp/assets/js/moment.min.js"></script>
<script src="/semana5/tallermvcphp/assets/js/windowcenter.js"></script>
<script src="/semana5/tallermvcphp/assets/js/print.window.js"></script>
<script src="/semana5/tallermvcphp/assets/js/validate.js"></script>
<script src="/semana5/tallermvcphp/assets/js/login.js"></script>
    